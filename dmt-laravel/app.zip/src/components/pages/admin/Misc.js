import React from "react";

const Misc = () => {
  return <div>Misc</div>;
};

export default Misc;
