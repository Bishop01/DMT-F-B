import React from 'react'

const Store = () => {
    return (
        <div className='flex flex-col w-full'>
            <img className='w-full' src='/images/assets/store.png' />
        </div>
    )
}

export default Store